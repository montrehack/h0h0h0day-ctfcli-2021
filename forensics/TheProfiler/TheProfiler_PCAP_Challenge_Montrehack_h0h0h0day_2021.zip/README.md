This PCAP contains a 🚩FLAG🚩. Do you have the required profile to find it? 👀
Flag format: FLAG-[0-9A-Z]+
Challenge Author: Res260 (Émilio Gonzalez)
